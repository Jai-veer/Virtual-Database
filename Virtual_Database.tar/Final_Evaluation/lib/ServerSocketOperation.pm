#!/usr/bin/perl -w
use strict;
use IO::Socket;
use Net::Address::IPv4::Local;
use CommonSocketOperation;
package ServerSocketOperation;
my $Port="4321";

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  CreateServer
#│ ☆ Arguments 		:  void 
#│ ☆ Description        :  to create a server
#│ ☆ Return Type        :  socket fd
#├──────────────────────────────────────────────

sub CreateServer {
        my $SSockFd = new IO::Socket::INET (LocalHost => Net::Address::IPv4::Local->public,LocalPort => $Port,Proto => 'tcp',Listen => 1,Reuse => 1);
        if(!defined($SSockFd)) {
                return undef;
        } else {
                print "SERVER started on port $Port\n";
                return $SSockFd;
        }
}

sub AcceptClient {
        my ($CSockFd,$SSockFd);
        $SSockFd=shift;
        $CSockFd=$SSockFd->accept();
        if(!defined($CSockFd)) {
                return undef;
        } else {
                print "Client Connected on port $Port\n";
                return $CSockFd;
        }
}

sub RecvQuery {
	my ($SockFd,$Query);
	$SockFd=shift;
	$Query=CommonSocketOperation::RecvMessage($SockFd);
	return $Query;
}

sub SendResponse {
	my ($SockFd,$Response);
	$SockFd=shift;
	$Response=shift;
	if(defined $Response) {
#		foreach ( split /:~:/, $Response ) {
			CommonSocketOperation::SendMessage($SockFd,$Response);	
#		}
	}
	#CommonSocketOperation::SendMessage($SockFd,"FINISH");
}
