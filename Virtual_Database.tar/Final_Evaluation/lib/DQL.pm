#!/usr/bin/perl -w
use strict;
package DQL;
use CommonServerFunction;

sub new {
	my $self={};
	bless($self,$_[0]);
	return $self;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      : select
#│ ☆ Arguments 		: hash, Query
#│ ☆ Description        : To select and return the table
#│ ☆ Return Type        : response
#├──────────────────────────────────────────────

sub select {
	my ($Query,$TableName,@Column,$NOC,$Where_Column,$Where_Value,$Original_Column,@Cols_Print,$Response,$Return,$Where,$Where_Flag,$Where_Return,$Table_Value);
	shift;
	$Query=shift;
	@Column = split /%~%/, (split /:~:/, $Query)[2];
	$Where = join ':~:',(split /:~:/, $Query)[3..5];
	$Where_Flag=1;
	if(!defined $Where || $Where eq "") {
		$Where_Flag=0;
	}
	($TableName,$NOC,$Where_Column,$Where_Value)=(split /:~:/, $Query) [1,3..5];
	if(CommonServerFunction::Check_Table($TableName)) {
		if(($Return=CommonServerFunction::Check_Column($TableName,@Column)) eq "OK") {
			open TABLE_DATA, $TableName;
			$Original_Column=<TABLE_DATA>;	
			chomp($Original_Column);
			@Cols_Print=Form_Select($Original_Column,@Column);
			foreach ((split /:~:/, $Original_Column)[@Cols_Print]) {
				$Response.=sprintf("%10s |",$_);
			}
			$Response.="\n";
			<TABLE_DATA>;
			foreach(@Cols_Print) {
				$Response.=sprintf("%11s+","-"x10);
			}
			$Response.="\n";
			while(defined($Table_Value=<TABLE_DATA>)) {
				if(defined $Table_Value) {
					chomp $Table_Value;
					if($Where_Flag==0) {
						foreach ((split /:~:/, $Table_Value)[@Cols_Print]) {
							$Response.=sprintf("%10s |",$_);
						}
						$Response.="\n";
					} elsif($Where_Flag==1) {
						if(($Where_Return=CommonServerFunction::Check_Where($TableName,$Table_Value,$Where))==1) {
							foreach ((split /:~:/, $Table_Value)[@Cols_Print]) {
								$Response.=sprintf("%10s |",$_);
							}
							$Response.="\n";
						} elsif($Where_Return==-1) {
							$Response="ERROR: Column \"".(split ':~:',$Where)[0]."\" doesn't exists\n";
							return $Response;
						} elsif($Where_Return==-2) {
							$Response="ERROR: invalid input syntax : ".(split ':~:',$Where)[2]."\n";
							return $Response;
						} 
					}
				} else {
					last;
				} 
			}
			return $Response;
		} 
		$Response.="ERROR:  column \"$Return\" does not exist\n";
		return $Response;
	}
	$Response.="ERROR:  relation \"$TableName\" does not exist\n";
	return $Response;
}

sub Form_Select {
	my (@Count,$Total,$Original_Column,@Column,$Match,$Count);
	$Original_Column=shift;
	@Column=@_;
	chomp(@Column);
	$Total=split /:~:/, $Original_Column;
	$Total--;
	foreach $Match(@Column) {
		$Count=0;
		if($Match eq "*") {
			push @Count, (0..$Total);
			goto Ok;
		} 
		foreach(split /:~:/, $Original_Column) {
			chomp($_);
			last if($Match eq $_);
			$Count++;
		}
		push @Count, $Count;
		Ok:
	}
	return @Count;
}
1;
