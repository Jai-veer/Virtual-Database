#!/usr/bin/perl -w
use strict;
use Tie::File;
package DDL;
use CommonServerFunction;

sub new {
	my $self={};
	bless($self,$_[0]);
	return $self;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  create 
#│ ☆ Arguments 		:  hash, query
#│ ☆ Description        :  to create a table in database
#│ ☆ Return Type        :  Response
#├──────────────────────────────────────────────

sub create {
	my ($Query,$TableName,$Columns,$Datatype,$Response);
	shift;
	$Query=shift;
	$TableName=(split /:~:/, $Query)[1];
	$Columns=join ':~:', (split /%~%/,(split /:~:/, $Query)[2]);
	$Datatype=join ':~:', (split /%~%/,(split /:~:/, $Query)[4]);
	if(! -e $TableName) { #Check whether the table already exists ?
		open TABLE, ">", $TableName;
		print TABLE "$Columns\n";
		print TABLE "$Datatype\n";
		$Response="CREATE TABLE\n";
		close TABLE;
		return $Response;
	}
	$Response="ERROR:  relation \"$TableName\" already exists\n"; #Error if already exists.
	return $Response;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      : truncate 
#│ ☆ Arguments 		: hash, query                                   
#│ ☆ Description        : to truncate a table 
#│ ☆ Return Type        : response
#├──────────────────────────────────────────────

sub truncate {
	my ($TableName,$Response,@Content);
	shift;
	$TableName=(split /:~:/, shift)[1];	
	$Response="";
	if(CommonServerFunction::Check_Table($TableName)) { #Check Whether table is present or not
		tie @Content, 'Tie::File',$TableName;
		splice(@Content,2);	
		$Response="TRUNCATE TABLE\n";
		return $Response;
	}
	$Response="ERROR:  relation \"$TableName\" does not exist\n"; #Error if doesn't exists.
	return $Response;
}

1;
