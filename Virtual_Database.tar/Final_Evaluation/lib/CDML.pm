#!/usr/bin/perl -w
use strict;
package CDML;
use Data::Dumper;

sub new {
        my $self={};
        bless($self,$_[0]);
        return $self;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  delete
#│ ☆ Arguments 		:  hash, query
#│ ☆ Description        :  to delete a table
#│ ☆ Return Type        :  Response
#├──────────────────────────────────────────────

sub delete {
	my ($Query,$Request,@Part,$Return);
	shift;
	$Query=shift;
	@Part=split ' ', $Query;
	return $Return if(defined($Return=Pattern_Check("$Part[0] $Part[1]",qr(delete from))));
	$Request="DELETE:~:";
	return $Return if(defined($Return=Pattern_Check($Part[2],qr([^\d]\w+(\d)?(_)?;?)))); 
	$Request.="$Part[2]";
	if(!defined($Return=Pattern_Check($Part[3],qr(where)))) {
		return $Return if(defined($Return=Pattern_Check("$Part[4] $Part[5] $Part[6]",qr([^\d][A-Za-z0-9_]+ ((=)|(<)|(>)|(!=)|(<>)|(<=)|(>=)){1} (\d+|\'.*\'))))); 
		$Request.=":~:$Part[4]:~:$Part[5]:~:$Part[6]";	
		return $Request;
	}
	$Request.=":~::~::~:";
	return $Request;
}

sub Pattern_Check {
	my ($Value,$Pattern);
	$Value= shift;
	$Pattern=shift;
	if(defined $Value ) {
		$Value= lc $Value;
		if($Value =~ /^$Pattern$/) {
			return undef;
		}
	}
	return "ERROR: syntax error at or near $Value\n" if(defined $Value);
	return "ERROR: syntax error at or near ( unavailable )\n";
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      : insert
#│ ☆ Arguments 		: hash, query
#│ ☆ Description        : to insert data into a table
#│ ☆ Return Type        :   0 or 1
#├──────────────────────────────────────────────

sub insert {
	my ($Query,$Request,$Return,@Values,@Columns,@Part,$Flag,$Repeat,$Match);
	shift;
	$Query= lc shift;
	if($Query=~/^ *insert +into +[^\d]\w+(\d)?(_)? +values *\(.*\) *;$/) {
		$Query=~s/^ *(insert +into) +([^\d][^\(]\w+(\d)?(_)?) +(values) *\( ?(.*) ?\) *;$/$1 $2 $5 ( $6 ) ;/g;
		$Flag=1;
	} elsif ($Query=~/^ *insert +into +[^\d]\w+(\d)?(_)? *\(.*\) *values *\(.*\) *;$/) {
		$Query=~s/^ *(insert +into) +([^\d][^\(]\w+(\d)?(_)?) *\( ?(.*) ?\) *(values) *\( ?(.*) ?\) *;$/$1 $2 ( $5 ) $6 ( $7 ) ;/g;
		$Flag=2;
	} else {
		@Part=split ' ', $Query;
		return $Return if(defined($Return=Pattern_Check("$Part[0] $Part[1]","insert into")));
		return $Return if(defined($Return=Pattern_Check($Part[2],qr([^\d][^\(]\w+(\d)?(_)?))));
		return "ERROR: syntax error at or near ( unavailable )\n";
	}
	@Part=split ' ', $Query;
	$Request="INSERT:~:$Part[2]:~:";
	if($Flag==1) {
		@Values=split ',',$Part[5];
		$Request.="*:~:$#Values:~:";
		foreach(@Values) {
			return $Return if(defined($Return=Pattern_Check($_,qr( ?(\d+|'\w+') ?))));
			$Request.="$_%~%";
		}
		chop($Request);
		chop($Request);
		chop($Request);
	} elsif($Flag==2) {
		@Columns=split ',',$Part[4];
		foreach(@Columns) {
			return $Return if(defined($Return=Pattern_Check($_,qr/ ?[A-Za-z](\w*)? ?/)));
			$Request.="$_%~%";
		}
		chop($Request);
		chop($Request);
		chop($Request);
		$Request.=":~:$#Columns:~:";
		@Values=split ',', $Part[8];
		foreach(@Values) {
			return $Return if(defined($Return=Pattern_Check($_,qr( ?(\d+|'\w+') ?))));
			$Request.="$_%~%";
		}
		chop($Request);
		chop($Request);
		chop($Request);
		if($#Columns!=$#Values) {
			return "ERROR:  INSERT has more expressions than target columns\n";
		}
		$Repeat=0;
		foreach $Match(@Columns) {
			foreach(@Columns) {
				if($Match eq $_) {
					if($Repeat==1) {
						return "ERROR:  column \"id\" specified more than once\n";
					} 
					$Repeat=1;
				}
			}
			$Repeat=0;
		}
	}
	return $Request;
}

sub update {
	my ($Query,$Return,@Part,$Request,$Flag);
	shift;
	$Query=lc shift;
	if($Query =~ /^ *update +([^\d][A-Za-z0-9_]+) +set +([^\d][A-Za-z0-9_]+) *= *(\'\w+\'|\d+) *;$/) {
		$Query =~ s/^ *update +([^\d][A-Za-z0-9_]+) +set +([^\d][A-Za-z0-9_]+) *= *(\'\w+\'|\d+) *;$/update $1 set $2 = $3 ;/g;
		$Flag=1;
	} elsif($Query =~ /^ *update +([^\d][A-Za-z0-9_]+) +set +([^\d][A-Za-z0-9_]+) *= *(\'\w+\'|\d+) +where +([^\d][A-Za-z0-9_]+) *((=)|(<)|(>)|(!=)|(<>)|(<=)|(>=)){1} *(\'\w+\'|\d+) *;$/) {
		$Query =~ s/^ *update +([^\d][A-Za-z0-9_]+) +set +([^\d][A-Za-z0-9_]+) *= *(\'\w+\'|\d+) +where +([^\d][A-Za-z0-9_]+) *((=)|(<)|(>)|(!=)|(<>)|(<=)|(>=)){1} *(\'\w+\'|\d+) *;$/update $1 set $2 = $3 where $4 $5 $13 ;/g;
		$Flag=2;
	} else {
		@Part=split ' ', $Query;
		return $Return if(defined($Return=Pattern_Check("$Part[0] $Part[2]","update set")));
		return $Return if(defined($Return=Pattern_Check("$Part[1] $Part[3] $Part[4]",qr(([^\d]\w+(\d)?(_)?) ([^    \d]\w+(\d)?(_)?) (\'\w+\'|\d)))));
		return "ERROR: syntax error at or near ( unavailable )\n";
	}
	@Part=split ' ', $Query;
	if($Flag==1) {
		$Request="UPDATE:~:$Part[1]:~:$Part[3]:~:$Part[5]:~::~::~:";
	} elsif($Flag==2) {
		$Request="UPDATE:~:$Part[1]:~:$Part[3]:~:$Part[5]:~:$Part[7]:~:$Part[8]:~:$Part[9]";
	}
	return $Request;
}
1;
