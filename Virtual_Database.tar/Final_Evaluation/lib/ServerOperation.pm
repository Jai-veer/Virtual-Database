#!/usr/bin/perl -w
use strict;
use DDL;
use DML;
use DQL;
package ServerOperation;
use Data::Dumper;
my ($Functions);
sub Start {
        my ($ddl,$dml,$dql);
        $ddl=DDL->new();
        $dml=DML->new();
        $dql=DQL->new();
        $Functions = { select=>$dql, create=>$ddl, delete=>$dml, truncate=>$ddl, insert=>$dml, update=>$dml};
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      : query
#│ ☆ Arguments 		: query
#│ ☆ Description        : to call the appropriate service
#│ ☆ Return Type        :  Response
#├──────────────────────────────────────────────

sub Query {
        my ($Query,@Segments);
        $Query=shift;
        @Segments=split ':~:',$Query;
        Start();
        if(defined $Segments[0]) {
                if(exists $Functions->{ (lc $Segments[0])}) {
                return $Functions->{create}->create($Query) if($Segments[0] =~ /^create$/gi);
                return $Functions->{delete}->delete($Query) if($Segments[0] =~ /^delete$/gi);
                return $Functions->{select}->select($Query) if($Segments[0] =~ /^select$/gi);
                return $Functions->{truncate}->truncate($Query) if($Segments[0] =~ /^truncate$/gi);
                return $Functions->{insert}->insert($Query) if($Segments[0] =~ /^insert$/gi);
		return $Functions->{update}->update($Query) if($Segments[0] =~ /^update$/gi);
                } else {
                        print "Service not available\n";
                }
        }
        return 0;
}
1;
