#!/usr/bin/perl -w
use strict;
use IO::Socket;
package CommonSocketOperation;
sub SendMessage {
        my ($SockFd,$Message);
        $SockFd=shift;
        $Message=shift;
        $SockFd->send(sprintf("%.5d%s",length $Message,$Message));
}

sub RecvMessage {
        my ($SockFd,$Message,$Size);
        $SockFd=shift;
        $SockFd->recv($Size,5);
	exit if(length $Size == 0);
        $SockFd->recv($Message,$Size+0);
        return $Message;
}
1;
