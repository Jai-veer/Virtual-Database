#!/usr/bin/perl -w
use strict;
package ClientQuery;

#├──────────────────────────────────────────────
#│ ☆ Function Name      :   Get_Query
#│ ☆ Arguments 		:  void 
#│ ☆ Description        :   To get input from the user.
#│ ☆ Return Type        :   Query
#├──────────────────────────────────────────────

sub Get_Query {
	my ($Query,$Full_Query);
	$Full_Query="";
	print "postgres=> ";
	while(1) {
		GetAgain:
		if(defined($Query=Input_Get())) {
			if($Query =~ /;{1}$/) {
				last if( $Full_Query eq ""  && $Query =~ /^;$/);
				$Full_Query .= " ";
				$Full_Query .= $Query;	
				last;
			} elsif ($Query =~ /.*;.*$/) {
				print "Input error : unexpected ';'\n";
				$Full_Query="";
				last;
			} else {
				$Full_Query .= " ";
				$Full_Query .= $Query;	
				print "postgres-> ";
				goto GetAgain;

			}
		}  elsif($Full_Query ne "") {
			print "postgres-> ";
			goto GetAgain;
		} else {
			last;
		}
	}
	if($Full_Query eq "") {
		return undef;
	} 
	$Full_Query =~ s/(.*);/$1 ;/g;
	return $Full_Query;
}

sub Input_Get {
	my $Input=<STDIN>;
	if(defined($Input)) {
		if($Input eq "\n") {
			chomp $Input;
		}
		if($Input eq "") {
			return undef;
		} else {
			chomp($Input);
			return $Input;
		}
	} 
	return undef;
}
1;
