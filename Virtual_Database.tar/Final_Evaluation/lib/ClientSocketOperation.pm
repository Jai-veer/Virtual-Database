#!/usr/bin/perl -w
use strict;
use IO::Socket;
use Net::Address::IPv4::Local;
use CommonSocketOperation;
my $Port="4321";
package ClientSocketOperation;

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  ConnectToServer 
#│ ☆ Arguments 		:  void
#│ ☆ Description        :  To connect to server in runing in any system
#│ ☆ Return Type        :  socket fd
#├──────────────────────────────────────────────

sub ConnectToServer {
	my (@Ip,$SSockFd);
	$Ip[0]=Net::Address::IPv4::Local->public;
	$Ip[1]="192.168.12.148";
	if(!defined(($SSockFd=ConnectServer($Ip[0])))) {
		if(!defined(($SSockFd=ConnectServer($Ip[1])))) {
			print "Unable to Connect to Server\n";
			return undef;
		}
	}
	return $SSockFd;
}

sub ConnectServer {
	my ($ServIp,$SockFd);
	$ServIp=shift;
	$SockFd = new IO::Socket::INET(PeerAddr => $ServIp,PeerPort => $Port,Proto => 'tcp');
	return $SockFd;
}

sub SendQuery {
	my ($SockFd,$Query);
	$SockFd=shift;
	$Query=shift;
	CommonSocketOperation::SendMessage($SockFd,$Query);	
}

sub RecvResponse {
	my ($SockFd,$Response,$Line);
	$SockFd=shift;
	$Response="";
#	do {
#		$Line=CommonSocketOperation::RecvMessage($SockFd);
#		$Response.=$Line;
#		$Response.="~:~";
#	} while($Line ne "FINISH");
#	if($Response eq "FINISH~:~") {
#		return undef;
#	} 
		$Response=CommonSocketOperation::RecvMessage($SockFd);
	return $Response;
}
