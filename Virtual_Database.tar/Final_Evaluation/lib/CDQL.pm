#!/usr/bin/perl -w
use strict;
package CDQL;

sub new {
        my $self={};
        bless($self,$_[0]);
        return $self;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      : select 
#│ ☆ Arguments 		: hash, query
#│ ☆ Description        : to select the table
#│ ☆ Return Type        : response
#├──────────────────────────────────────────────

sub select {
	my ($Query,$Request,@Part,$Return,@Columns);
	shift;
	$Query=shift;
	@Part=split ' ',$Query;
	return $Return if(defined($Return=Pattern_Check($Part[0],qr(select))));
	$Request="SELECT:~:";
	return $Return if(defined($Return=Pattern_Check($Part[2],qr(from))));
	return $Return if(defined($Return=Pattern_Check($Part[3],qr([^\d]\w+(\d)?(_)?;?))));
	chop($Part[3]) if( $Part[3] =~ /.*;/);
	$Request.="$Part[3]:~:";
	if(defined $Part[1]) {
		$Return="ERROR: syntax error at or near $Part[1]\n";
		return $Return if(!defined(Pattern_Check(($Part[1],","))));
		@Columns=split ',',$Part[1];
		foreach(@Columns) {
			return $Return if(defined($Return=Pattern_Check(($_,qr(([^\d]\w+(\d)?(_)?)|\*)))));
			$Request.="$_%~%";
		}
		chop($Request);
		chop($Request);
		chop($Request);
	}
	if(!defined($Return=Pattern_Check($Part[4],qr(where)))) {
		return $Return if(defined($Return=Pattern_Check("$Part[5] $Part[6] $Part[7]",qr(([^\d][A-Za-z1-9_]+) ((=)|(<)|(>)|(!=)|(<>)|(<=)|(>=)){1} (\'\w+\'|\d)))));
		$Request.=":~:$Part[5]:~:$Part[6]:~:$Part[7]";
		return $Request;
	}
	$Request.=":~::~::~:";
	return $Request;
}

sub Pattern_Check {
	my ($Value,$Pattern);
	$Value= shift;
	$Pattern=shift;
	if(defined $Value ) {
		$Value= lc $Value;
		if($Value =~ /^$Pattern$/) {
			return undef;
		}
	}
	return "ERROR: syntax error at or near $Value\n" if(defined $Value);
	return "ERROR: syntax error at or near ( unavailable )\n";
}
1;
