#!/usr/bin/perl -w
use strict;
package CDDL;

sub new {
	my $self={};
	bless($self,$_[0]);
	return $self;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  Create 
#│ ☆ Arguments 		:  hash , Query
#│ ☆ Description        :  to create a table
#│ ☆ Return Type        :  Response 
#├──────────────────────────────────────────────

sub create {
	my ($Request,$Query,$Return,@Part,@Column_Datatype,@Column,@Datatype,$Count,$Size);
	shift;
	$Query=lc shift;
	$Query=~s/(create +table) +([^\d]\w+(\d)?(_)?) *\( ?(.*) ?\) *;/$1 $2 ( $5 ) ;/g;
	@Part=(split ' ',$Query)[0..2];
	return $Return if(defined($Return=Pattern_Check("$Part[0] $Part[1]",qr(create table))));
	$Request="CREATE:~:";
	return $Return if(defined($Return=Pattern_Check($Part[2],qr([^\d]\w+(\d)?(_)?))));
	$Request.="$Part[2]:~:";
	$Query =~ m/\( (.*) \)/;
	@Column_Datatype=split ',',$1;
	foreach(@Column_Datatype) {
		return $Return if(defined($Return=Pattern_Check((split ' ',$_)[0],qr([^\d]\w+(\d)?(_)?))));
		if(defined($Return=Pattern_Check((split ' ',$_)[1],qr/char|varchar|int|bool|text/))) {
			if(((split ' ',$_)[1]=~/(char|varchar)\((.*)\)/)) {
				$Size=$2;
				if(!($Size=~/^\d+$/)) {
					return $Return;	
				}
			}
		}
		push @Column, (split ' ',$_)[0];
		push @Datatype, (split ' ',$_)[1];
	}
	foreach(@Column) {
		$Request.="$_%~%";
	}
	chop($Request);
	chop($Request);
	chop($Request);
	$Request.=":~:$#Column:~:";
	foreach(@Datatype) {
		$Request.="$_%~%";
	}
	chop($Request);
	chop($Request);
	chop($Request);
	return $Request;
}

sub Pattern_Check {
	my ($Value,$Pattern);
	$Value= shift;
	$Pattern=shift;
	if(defined $Value ) {
		$Value= lc $Value;
		if($Value =~ /^$Pattern$/) {
			return undef;
		}
	}
	return "ERROR: syntax error at or near $Value\n" if(defined $Value);
	return "ERROR: syntax error at or near ( unavailable )\n";
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      :   truncate 
#│ ☆ Arguments 		:   hash , Query                                 
#│ ☆ Description        :   truncate the table 
#│ ☆ Return Type        :   0 or 1
#├──────────────────────────────────────────────

sub truncate {
	my ($Query,$Request,@Part,$Return);
	shift;
	$Query=shift;
	@Part=split ' ',$Query;
	return $Return if(defined($Return=Pattern_Check($Part[0],qr(truncate)))) ;
	return $Return if(defined($Return=Pattern_Check("$Part[1]",qr([^\d]\w+(\d)?(_)?;?)))) ;
	chop($Part[1]) if($Part[1] =~ /.*;/);
	$Request ="TRUNCATE:~:$Part[1]";
	return $Request;
}
1;
