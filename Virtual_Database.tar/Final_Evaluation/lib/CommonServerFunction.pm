#!/usr/bin/perl -w
use strict;
package CommonServerFunction;

sub Check_Table {
        my ($TableName);
        $TableName=shift;
        return 1 if(-e -r -w $TableName);
        return 0;
}

sub Datatype_Value {
        my ($Datatype,$Value,$Pattern);
        $Datatype=shift;
        $Value=shift;
        if(defined $Value) {
                if($Datatype =~ /^int(\(.*\))?$/) {
                        return 1 if($Value =~ /^\d+$/);
                } elsif ($Datatype =~ /^varchar$/) {
                        return 1 if($Value =~ /^'.*'$/);
                } elsif($Datatype =~ /^varchar\[(\d+)\]$/) {
                        $Pattern=$1;
                        return 1 if($Value =~ /^'.{0,$Pattern}'$/);
                } elsif($Datatype =~ /^text$/) {
                        return 1 if($Value =~ /^'.+'$/);
                } elsif($Datatype =~ /^char$/) {
                        return 1 if($Value =~ /^'.'$/);
                } elsif($Datatype =~ /^char\[(\d+)\]$/) {
                        $Pattern=$1;
                        return 1 if($Value =~ /^'.{0,$Pattern}'$/);
                } elsif($Datatype =~ /^bool$/) {
                        return 1 if($Value =~ /^((true)|(false)|1|0|t|f)?$/);
                }
        }
        return 0;
}

sub Check_Column {
        my ($TableName,$NOC,@Column,@Orginal_Columns,$Flag,$Match,$Column,$Error);
        $TableName=shift;
        @Column=@_;
        chomp (@Column);
        $Flag=1;
        open TABLE, $TableName;
        @Orginal_Columns=split /:~:/, <TABLE>;
        foreach $Match (@Column) {
                foreach(@Orginal_Columns) {
                        chomp($_);
                        goto Ok if($Match eq $_ || $Match eq "*");
                }
                $Error.="," if($Flag==0);
                $Error.=$Match;
                $Flag=0;
                Ok:
        }
        return "OK" if($Flag == 1);
        return $Error;
}

sub Check_Where {
        my ($TableName,$ColumnData,$Where,$TableColumn,$Column,$Data,$Expression,$Count,$Value,$Flag,$TableDatatype);
        $TableName=shift;
        $Flag=0;
        $Count=0;
        chomp($ColumnData=shift);
        chomp($Where=shift);
        $Column=(split ':~:',$Where)[0];
        $Expression=(split ':~:',$Where)[1];
        $Data=(split ':~:',$Where)[2];
        open TABLE, $TableName;
        chomp($TableColumn=<TABLE>);
        chomp($TableDatatype=<TABLE>);
        foreach(split ':~:',$TableColumn) {
                if($Column eq $_) {
                        $Flag=1;
                        last;
                }
                $Count++;
        }
        if($Flag) {
                $Value=(split ':~:', $ColumnData)[$Count];
                if(CommonServerFunction::Datatype_Value((split ':~:',$TableDatatype)[$Count],$Data)) {
                        if($Expression eq "=") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value eq $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value == $Data);

                                }
                        } elsif($Expression eq "<=") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value le $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value <= $Data);
                                }
                        } elsif($Expression eq ">=") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value ge $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value >= $Data);
                                }
                        } elsif($Expression eq "!=") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value ne $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value != $Data);
                                }
                        } elsif($Expression eq "<>") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value ne $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value != $Data);
                                }
                        } elsif($Expression eq "<") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value lt $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value < $Data);
                                }
                        } elsif($Expression eq ">") {
                                if($Data =~ /^\'.*\'$/) {
                                        return 1 if($Value gt $Data);
                                } elsif($Data =~ /^\d+$/) {
                                        return 1 if($Value > $Data);
                                }
                        }
                } else {
                        return -2;
                }
        } else {
                return -1;
        }
        return 0;
}
sub daemonize {
        my $pid = fork ();
        if ($pid < 0) {
                die "fork: $!";
        } elsif ($pid) {
                exit 0;
        }
        foreach (0 .. (POSIX::sysconf (&POSIX::_SC_OPEN_MAX) || 1024))
        { POSIX::close $_ }
        open (STDIN, "</dev/null");                                                                                        
        open (STDOUT, ">/dev/null");
        open (STDERR, ">&STDOUT");
}
1;
