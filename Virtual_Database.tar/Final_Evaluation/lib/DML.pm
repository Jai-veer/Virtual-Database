#!/usr/bin/perl -w
use strict;
use Tie::File;
package DML;
use CommonServerFunction;

sub new {
	my $self={};
	bless($self,$_[0]);
	return $self;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  delete
#│ ☆ Arguments 		:  hash, tablename
#│ ☆ Description        :  to delete a tbale
#│ ☆ Return Type        :   0 or 1
#├──────────────────────────────────────────────

sub delete {
	my ($TableName,$Response,$Count,@Content,$Request,$Where,$Return,$Check_Count);
	shift;
	$Request=shift;
	$Where=join ':~:',(split ':~:',$Request)[2..4];
	$TableName=(split /:~:/, $Request)[1];	
	$Response="";
	if(CommonServerFunction::Check_Table($TableName)) { #check Where the table exists or not ?
		tie @Content, 'Tie::File',$TableName;
		if(!defined $Where || $Where eq "") { #This part will get executed when there is no where condition.
			$Count=$#Content-1;
			splice(@Content,2);	
		} else {
			$Check_Count=$#Content;
			while($Check_Count>=2) { #This part will get executed when there is where condition
				if(($Return=CommonServerFunction::Check_Where($TableName,$Content[$Check_Count],$Where))==1) {
					splice(@Content,$Check_Count,1);	
					$Count++;
				} elsif($Return==-1) { #error when the mentioned where column doesn't exist.
					$Response="ERROR: column \"".(split ':~:',$Where)[0]."\" does not exist";
					return $Response;
				} elsif($Return==-2) { #error when the mentioned where value doesn't seem similar to datatype;
					$Response="ERROR: invalid input syntax: \"".(split ':~:',$Where)[2]."\"\n";
					return $Response;
				}
				$Check_Count--;
			}
		}
			$Response="DELETE $Count\n";  #Delete count as response.
			return $Response;
	}
		$Response="ERROR:  relation \"$TableName\" does not exist\n"; #error when table doesn't exist.
		return $Response;
}

#├──────────────────────────────────────────────
#│ ☆ Function Name      :  insert 
#│ ☆ Arguments 		:  hash, query
#│ ☆ Description        :  to insert into a table
#│ ☆ Return Type        :  response
#├──────────────────────────────────────────────

sub insert {
	my ($Query,$TableName,$Columns,$Values,$Return,$Response);
	shift;
	chomp($Query=shift);
	$TableName=(split /:~:/, $Query)[1];
	if((split /:~:/, $Query)[2] eq "*") {
		open TABLE, $TableName;
		chomp($Columns=<TABLE>);
	} else {
		$Columns=join ':~:', (split /%~%/, (split /:~:/, $Query)[2]);
	}
	$Values=join ':~:', (split /%~%/, (split /:~:/, $Query)[4]);
	unless(($Return=Form_Input($TableName,$Columns,$Values)) =~ /^ERROR.*$/) { #This will form input for the came request to store it in file.
		open INSERT, ">>", $TableName;
		print INSERT "$Return\n";
		close INSERT;
		$Response="INSERT 0 1\n";	
	} else {
		$Response=$Return;	
	}
	return $Response;
}

sub update {
	my ($Query,$TableName,$Column,$Value,$Return,$Orginal_Column,$Orginal_Datatype,$Count,@Temp,$Updated,$Where,$Where_Flag,$Check_Where);    
	shift;
	$Query=shift;
	$Where_Flag=0;
	$Updated=0;
	$TableName=(split ':~:', $Query)[1];
	$Column=(split ':~:', $Query)[2];
	$Value=(split ':~:', $Query)[3];
	$Where=join ':~:',(split ':~:',$Query)[4..6];
	if(defined $Where && $Where eq "") {
		$Where_Flag=1;
	}
	if(-e $TableName) { #Check Whether the table exists or not
		if(($Return=CommonServerFunction::Check_Column($TableName,$Column)) eq "OK") {
			open TABLE, $TableName;
			chomp ($Orginal_Column=<TABLE>);
			chomp ($Orginal_Datatype=<TABLE>);
			$Count=0;
			foreach((split ':~:',$Orginal_Column)) {
				if($_ eq $Column) {
					last;
				}
				$Count++;	
			}	
			if(CommonServerFunction::Datatype_Value((split ':~:',$Orginal_Datatype)[$Count],$Value)) { #Check whether give datatype are right or wrong
				tie my @Table, 'Tie::File', $TableName;
				if($Where_Flag==1) {
					foreach(2..$#Table) {
						@Temp = split ':~:', $Table[$_];
						$Temp[$Count]=$Value;
						$Table[$_]=join ':~:', @Temp;
						$Updated=$_;
					}
					$Updated-=1;
				} elsif($Where_Flag==0) {
						foreach(2..$#Table) {
							if(($Check_Where=CommonServerFunction::Check_Where($TableName,$Table[$_],$Where))==1) {
								@Temp = split ':~:', $Table[$_];
								$Temp[$Count]=$Value;
								$Table[$_]=join ':~:', @Temp;
								$Updated++;
							} elsif($Check_Where==-1) {
								return "ERROR: Column \"".(split ':~:',$Where)[0]."\" doesn't exists\n";
							} elsif($Check_Where==-2) {
								return "ERROR: invalid input syntax: \"".(split ':~:',$Where)[2]."\"\n";
							}
						}
				}
				return "UPDATE $Updated\n";
			} else {
				return "ERROR: Invalid Input syntax for ".(split ':~:',$Orginal_Datatype)[$Count]." : $Value\n";
			}
		} else {
			return "ERROR: Column $Column doesn't exists\n";
		}
	} else {
		return "ERROR: Relation $TableName doesn't exists\n";
	}
}

sub Form_Input {
	my ($TableName,$Original_Column,$Original_Datatype,$Column,$Value,$Count,$MainCount,$Flag,$Return,$Match,@Columns,@Position,$Error);
	$TableName=shift;
	$Column=shift;
	$Value=shift;
	$Flag=0;
	if(($Return=CommonServerFunction::Check_Column($TableName,(split /:~:/, $Column))) eq "OK") {
		open TABLE, $TableName;
		$Original_Column=<TABLE>;
		$Original_Datatype=<TABLE>;
		chomp($Original_Column);
		chomp($Original_Datatype);
		$MainCount=0;
		$Flag=1;
		foreach $Match(split /:~:/,$Column) {
			$Count=0;
			foreach(split /:~:/,$Original_Column) {
				if($Match eq $_) {
					if(CommonServerFunction::Datatype_Value((split /:~:/,$Original_Datatype)[$Count],(split /:~:/,$Value)[$MainCount])) {
						push @Position, $Count;	
						goto Next;
					} else {
						$Error="ERROR:  invalid input syntax for ".(split /:~:/, $Original_Datatype)[$Count].":".(split /:~:/, $Value)[$MainCount];
					}
				}
				$Count++;
			}
			$Flag=0;
			last;
			Next:
			$MainCount++;
		}
	} else {
		$Error="ERROR:  column \"$Return\" of relation \"$TableName\" does not exist\n";
	}
	$Return="";
	if($Flag!=0) {
		@Columns[@Position]=(split /:~:/, $Value);
		foreach(@Columns) {
			if(defined $_) {
				$Return.="$_";
			}
			$Return.=':~:';
		}
		chop($Return);
		chop($Return);
		chop($Return);
		return $Return;
	} else {
		return $Error;
	}
}
1;
