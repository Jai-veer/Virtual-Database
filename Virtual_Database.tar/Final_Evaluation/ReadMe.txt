README
======
* I have finished the requirement like create,update,delete,truncate,insert,select with where condition.
* I have made the code flexible as possible for syntax like for leaving space.
* To run the database please move to bin/ using the command [ cd bin/ ].
* Have parallel terminals in one of them run [ perl Server.pl ] and in other one run [ perl Client.pl ]
* The Client.pl will be the query getting side which communicated with the database server and fetches data or store data.
* You can execute below queries to use the database.
* To Use Create have the syntax like [ create table tablename ( column1 [int|char|varchar|bool|text],column2 char[3] ); ]
	For Example : [ create table sample ( id int,name varchar ); ]
* To Use Insert have the syntax like [ insert table tablename values ( value1,'value2' ); | insert table tablename ( column1,column2 ) values ( value1,'value2' ); ]
	For Example : [ insert into sample values ( 1,'jaiveer' ); OR insert into sample ( id,name ) values ( 2,'jaiveer' ); ]
* To Use Update have the syntax like [ update tablename set column1 = [value1|'value1'] (where column2 = value2)? ; ]
	For Example : [ update sample set name = 'samraj' where id = 2 ; OR update sample set name = 'samraj' ; ]
* To Use Select have the syntax like [ select columnlist from tablename (where column = value)? ; ]
	For Example : [ select * from sample ; OR select id,id,name,id,name from sample where name = 'samraj' ; ]
* To Use Delete have the syntax like [ delete from tablename (where column = value)? ; ]
	For Example : [ delete from sample ; OR delete from sample where id = 1 ; ]
* To Use Truncate have the syntax like [ truncate tablename ; ]
	For Example : [ truncate sample ; ]

